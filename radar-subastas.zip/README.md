# Radar Subastas

Proyecto inicial con **Next.js** desplegado en **Cloudflare Pages**.
