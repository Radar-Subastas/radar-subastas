export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🚀 Radar Subastas</h1>
      <p>Bienvenido a tu primera app desplegada en Cloudflare Pages con Next.js</p>
    </div>
  );
}
